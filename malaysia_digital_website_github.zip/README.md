# Malaysia Digital — Website Tugasan 3

## Kandungan
- `index.html`: Website lengkap dalam satu fail (HTML, CSS dan JavaScript).
- Navigasi: Utama, Aspirasi, Pengaruh, Kesan, Data, Tindakan, Kuiz dan Rujukan.
- Responsif untuk komputer dan telefon.
- Aktiviti klik, senario, kuiz berskor, refleksi dan progress bar.

## Cara melihat website
Buka `index.html` menggunakan pelayar web.

## Cara menerbitkan menggunakan GitHub Pages
1. Cipta repository baharu di GitHub.
2. Muat naik `index.html` ke bahagian utama (root) repository.
3. Buka **Settings → Pages**.
4. Pada **Build and deployment**, pilih **Deploy from a branch**.
5. Pilih branch `main` dan folder `/ (root)`, kemudian tekan **Save**.
6. Tunggu GitHub Pages menerbitkan website dan buka URL yang diberikan.

## Ciri interaktif
- Navigasi antara 8 bahagian.
- Kad aspirasi boleh diklik untuk memaparkan penerangan.
- Tab lima aspek pengaruh teknologi.
- Aktiviti penilaian situasi.
- Kuiz 5 soalan dengan skor dan maklum balas automatik.
- Refleksi akhir dan borang refleksi setempat.

## Perkara yang perlu disiapkan oleh kumpulan
- Tambah nama ahli kumpulan, kelas, pensyarah dan institusi.
- Untuk undian atau maklum balas langsung merentas peranti, sambungkan Google Forms, Microsoft Forms, Mentimeter atau Slido. Borang refleksi dalam fail ini hanya menyimpan data secara setempat pada peranti dan tidak dihantar kepada pembentang.
- Jalankan mini kajian komuniti sebenar jika mahu mendakwa telah melaksanakan elemen Extension. Paparkan kaedah, tarikh, bilangan responden dan dapatan agregat dengan izin responden.
- Pastikan semua imej/video/audio luaran mempunyai lesen yang sesuai. Reka bentuk ini menggunakan emoji dan CSS, bukan imej pihak ketiga.
- Semak sumber asal dan nota metodologi sebelum pembentangan.

## Statistik
Berdasarkan penerbitan DOSM yang tersedia setakat 2 November 2026:
- Penggunaan internet individu berumur 15 tahun ke atas: 98.3% (2025).
- Akses internet isi rumah: 97.1% (2025).
- Akses isi rumah bandar: 99.0%; luar bandar: 90.7% (2025).
- Industri ICT dan e-dagang: RM476.8 bilion atau 23.5% KDNK (2025).
